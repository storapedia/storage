var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/prepare-blob-upload.js
var prepare_blob_upload_exports = {};
__export(prepare_blob_upload_exports, {
  default: () => prepare_blob_upload_default
});
module.exports = __toCommonJS(prepare_blob_upload_exports);
var import_blobs = require("@netlify/blobs");
var prepare_blob_upload_default = async (req) => {
  if (req.method !== "GET") {
    return new Response("Method Not Allowed", { status: 405 });
  }
  const url = new URL(req.url);
  const { searchParams } = url;
  const key = searchParams.get("key");
  const contentType = searchParams.get("contentType");
  if (!key || !contentType) {
    return new Response("Missing 'key' or 'contentType' query parameters", {
      status: 400
    });
  }
  const store = (0, import_blobs.getStore)("default");
  try {
    const { url: uploadUrl, publicUrl } = await store.getSignedURL(key, {
      expiresIn: 3600,
      // Berlaku selama 1 jam
      access: "public",
      method: "PUT"
    });
    return new Response(JSON.stringify({ uploadUrl, publicUrl }), {
      headers: { "Content-Type": "application/json" },
      status: 200
    });
  } catch (error) {
    console.error("Error generating signed URL:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500
    });
  }
};
